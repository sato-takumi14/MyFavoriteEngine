#pragma once
#include "gameObject.h"
#include "renderer.h"
#include <list>
#include <typeinfo>
#include <vector>
#include <map>
#include <string>

#include "debugCamera.h"
#include "imguiManager.h"
#include"textureManager.h"
#include "modelManager.h"
#include "post.h"
using namespace std;

class Scene
{
private:
	list<GameObject*> m_GameObjects;
	map<string, int> m_DrawOder;

	int m_LayerNum = 0;
	Post m_Post{};


public:

	void SetLayer(string name) 
	{
		m_DrawOder[name] = m_LayerNum++;
	}
	void SetLayer(string name,int num) 
	{
		if (num == m_LayerNum)
		{
			m_DrawOder[name] = m_LayerNum++;
		}
		else if (num < m_LayerNum)
		{
			for (int i = m_LayerNum - 1; i > num; i--)
			{
				string key;
				for (const auto& pair : m_DrawOder) {
					if (pair.second == i) {
						key = pair.first;
						break; // ���������烋�[�v�𔲂���
					}
				}
				m_DrawOder[key] = i + 1;
			}
			m_LayerNum++;
			m_DrawOder[name] = num;
		}
		else
		{
			assert("�v�f���͂���Ȃɂ���܂���");
		}
	}

	virtual void Init()
	{
		SetLayer("None");

		//�����_�����O�e�N�X�`����������邩���߂�
		for (int i = 0; i < 2; i++)
		{
			Renderer::CreateTexture(i);
		}
		m_Post.Init();

	}

	virtual void Uninit()
	{
		for (GameObject* gameObject:m_GameObjects)
		{
			gameObject->Uninit();
			delete gameObject;
		}

		m_Post.Uninit();
		m_GameObjects.clear();
		TextureManager::Uninit();
		ModelManager::Uninit();
	}

	virtual void Update()
	{
		for (GameObject* gameObject : m_GameObjects)
		{
			gameObject->Update();
		}
		m_GameObjects.remove_if([](GameObject* object) {return object->Destroy(); });

		m_Post.Update();
	}

	virtual void Draw()
	{
#ifdef _DEBUG
		DebugCamera::Draw();
#endif
		for (int j = 0; j < Renderer::GetNumRenderTexture(); j++)
		{
			Renderer::Begin(j);

			for (GameObject* gameObject : m_GameObjects)
			{
				if (gameObject->GetRTextureId(j) == j)
				{
					for (int i = 0; i < m_LayerNum; i++)
					{

						if (m_DrawOder["fade"] == gameObject->GetLayerNum())
						{
							Renderer::BeginPP();
#ifndef _DEBUG
							m_Post.Draw();
							gameObject->Draw();
#endif // !_DEBUG
						}
#ifdef _DEBUG
						else if (m_DrawOder["camera"] == gameObject->GetLayerNum())
						{
							if (ImguiManager::GetDrawCamera())
							{
								if (i == gameObject->GetLayerNum())
									gameObject->Draw();
							}
							else
							{
							}
						}
#endif // _DEBUG
						else if (i == gameObject->GetLayerNum())
							gameObject->Draw();
					}
				}
			}
		}
		//Layer::Draw();

	}

	template<typename T>
	T* AddGameObject(string name = "None")
	{
		GameObject* gameObject = new T;
		m_GameObjects.push_back(gameObject);
		gameObject->Init();

		gameObject->SetLayerNum(m_DrawOder[name]);
		gameObject->SetRTextureId();

		return dynamic_cast<T*>(gameObject);
	}


	template<typename T>
	T* AddGameObjectRT(string name = "None", vector<int> id = nullptr)
	{
		GameObject* gameObject = new T;
		m_GameObjects.push_back(gameObject);
		gameObject->Init();

		gameObject->SetLayerNum(m_DrawOder[name]);
		gameObject->SetRTextureId(id);

		return dynamic_cast<T*>(gameObject);
	}

	template<typename T>
	std::vector<T*>GetGameObjects()
	{
		std::vector<T*>objects;
		for (GameObject* object : m_GameObjects)
		{
			if (typeid(*object) == typeid(T))
			{
				objects.push_back((T*)object);
			}
		}
		return objects;
	}
};