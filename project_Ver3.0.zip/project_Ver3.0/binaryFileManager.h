#pragma once
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class BinaryFileManager
{
private:
	string filename;
	fstream fileStream;
public:
	BinaryFileManager(const string& filename) : filename(filename) {}

    //�t�@�C���̍쐬
    bool createFile() {
        fileStream.open(filename, ios::out | ios::binary);
        if (fileStream.is_open()) {
            fileStream.close();
            return true;
        }
        return false;
    }

    //�t�@�C���̃��[�h
    bool openFileForRead() {
        fileStream.open(filename, ios::in | ios::binary);
        return fileStream.is_open();
    }

    //�t�@�C���G�̏�������
    bool openFileForWrite() {
        fileStream.open(filename, ios::out | ios::binary);
        return fileStream.is_open();
    }

    //�t�@�C�������
    void closeFile() {
        if (fileStream.is_open()) {
            fileStream.close();
        }
    }


    template<typename T>
    void write(const T& data) {
        fileStream.write(reinterpret_cast<const char*>(&data), sizeof(T));
    }

    template<typename T>
    void read(T& data) {
        fileStream.read(reinterpret_cast<char*>(&data), sizeof(T));
    }

    template<typename T>
    void writeVector(const vector<T>& data) {
        write(static_cast<size_t>(data.size()));
        fileStream.write(reinterpret_cast<const char*>(data.data()), data.size() * sizeof(T));
    }

    template<typename T>
    void readVector(vector<T>& data) {
        size_t size;
        read(size);
        data.resize(size);
        fileStream.read(reinterpret_cast<char*>(data.data()), size * sizeof(T));
    }

};


