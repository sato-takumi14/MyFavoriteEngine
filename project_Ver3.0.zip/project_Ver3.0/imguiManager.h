#pragma once

#ifdef _DEBUG

class  ImguiManager
{
private:
	static char m_Buffer[1024];
	static bool m_IsDrawCamera;
public:
	static void Init();
	static void Uninit();
	static void Begin();
	static void End();
	static bool GetDrawCamera() { return m_IsDrawCamera; }
};
#endif // _DEBUG