#include "main.h"
#include "manager.h"
#include "renderer.h"
#include "imguiManager.h"
#include "debugCamera.h"

#include "scene.h"
#include "input.h"
#include "post.h"
#include "title.h"
#include "game.h"
#include "load.h"

Scene* Manager::m_Scene{};//�ÓI�����o�ϐ��͍Đ錾���K�v
Scene* Manager::m_NextScene{};
Scene* Manager::m_NextSceneLoad{};

//ImGuiManager�̓f�o�b�O��p
void Manager::Init()
{
	Renderer::Init();
#ifdef _DEBUG
	ImguiManager::Init();
	DebugCamera::Init();

#endif // DEBUG
	Input::Init();

	SetScene<Game>();

}

void Manager::Uninit()
{
	m_Scene->Uninit();
	delete m_Scene;


	Input::Uninit();
#ifdef _DEBUG
	ImguiManager::Uninit();
#endif // _DEBUG
	Renderer::Uninit();
}

void Manager::Update()
{
	Input::Update();


	if (m_NextScene)
	{
		if (m_Scene)
		{
			m_Scene->Uninit();
			delete m_Scene;
		}

		m_Scene = m_NextScene;
		m_Scene->Init();

		m_NextScene = nullptr;
	}

	if (m_NextSceneLoad)
	{
		if (m_Scene)
		{
			m_Scene->Uninit();
			delete m_Scene;
		}

		
		m_Scene = m_NextSceneLoad;
		

		m_NextSceneLoad = nullptr;
	}

#ifndef _DEBUG
	m_Scene->Update();
#endif // !_DEBUG

#ifdef _DEBUG
	if(!ImguiManager::GetDrawCamera())
	DebugCamera::Update();

#endif // _DEBUG

}

void Manager::Draw()
{
#ifdef _DEBUG
	ImguiManager::Begin();
#endif // _DEBUG
    m_Scene->Draw();

#ifdef _DEBUG
	ImguiManager::End();
#endif // _DEBUG
	Renderer::End();

}

void Manager::SetSceneLoad(Scene* next_scene)
{
	m_NextScene = new Load(next_scene);
}