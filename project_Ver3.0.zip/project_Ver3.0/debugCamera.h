#pragma once
#ifdef _DEBUG

class DebugCamera
{
private:
	static class Transform* m_Transform;
	static Vector3	    m_Target;
	static D3DXMATRIX m_ViewMatrix;
public:
	static void Init();
	static void Update();
	static void Draw();
};
#endif // _DEBUG