#ifdef _DEBUG
#include"main.h"
#include"renderer.h"
#include "debugCamera.h"
#include "input.h"
#include "transform.h"
#include "imgui.h"

Transform* DebugCamera::m_Transform;

Vector3	    DebugCamera::m_Target;
D3DXMATRIX  DebugCamera::m_ViewMatrix;

void DebugCamera::Init()
{
	m_Transform = new Transform();
	m_Transform->SetWorldPosition(Vector3(0.0f, 5.0f, -7.0f));
	m_Target = Vector3(0.0f, 0.0f, 0.0f);
	//m_Param = D3DXVECTOR4(10.0f, 50.0f, 3.5f, 0.0f);
	//m_FogColor = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	//m_GroundFogColor = D3DXCOLOR(0.5f, 0.0f, 0.5f, 1.0f);
}

void DebugCamera::Update()
{
	static Vector2 centerpos = Input::GetMousePos();
	static Vector3 centerrot = m_Transform->GetWorldRotation();
	//static bool flg = false;
	
	if (Input::GetMouseInput(MOUSE_DOWN_LEFT))
	{
		centerpos = Input::GetMousePos();
		centerrot = m_Transform->GetWorldRotation();

	}

	//if (Input::GetMouseInput(MOUSE_UP_LEFT))
	//{
	//	centerrot = m_Transform->GetWorldRotation();

	//}
	if(Input::GetMouseInput(MOUSE_TRIGGER_LEFT))
	{
		Vector2 vec = Input::GetMousePos() - centerpos;
		//if (vec.x > SCREEN_WIDTH * 0.5f)
		//{
		//	vec.x = SCREEN_WIDTH * 0.5f;
		//}
		//if (vec.x < -SCREEN_WIDTH * 0.5f)
		//{
		//	vec.x = -SCREEN_WIDTH * 0.5f;
		//}
		//if (vec.y > SCREEN_HEIGHT * 0.5f)
		//{
		//	vec.y = SCREEN_HEIGHT * 0.5f;
		//}
		//if (vec.y < -SCREEN_HEIGHT * 0.5f)
		//{
		//	vec.y = -SCREEN_HEIGHT * 0.5f;
		//}
		//m_Transform->SetWorldRotation(centerrot + (m_Transform->GetRight() * ((vec.y / SCREEN_HEIGHT * 0.7f) * D3DX_PI / 2.0f) +
		//										   m_Transform->GetUp() * ((vec.x / SCREEN_WIDTH * 0.7f) * D3DX_PI / 2.0f)));

		m_Transform->SetWorldRotation(centerrot + (Vector3().Right() * ((vec.y / SCREEN_HEIGHT * 1.0f) * D3DX_PI / 2.0f) +
			Vector3().Up() * ((vec.x / SCREEN_WIDTH * 1.0f) * D3DX_PI / 2.0f)));

		m_Transform->Rotate(Vector3(0.01f,0.01f,0.0f));
		//m_Transform->Rotate(m_Transform->GetRight() * vec.y / 10.0f);
		//centerpos = Input::GetMousePos();
	}
	//if (Input::GetMousePress(RButtonUp))
	//{
	//	flg = false;
	//}
	//if(flg)
	//{
		
	m_Target = m_Transform->GetWorldPosition() + m_Transform->GetForward();
	//m_Target.z += 0.1f;
}

void DebugCamera::Draw()
{
	Vector3 pos = m_Transform->GetWorldRotation();
	ImGui::Text("position x%f y%f z%f", pos.x, pos.y, pos.z);

	Vector3 up = m_Transform->GetUp();
	Vector3 position = m_Transform->GetWorldPosition();
	D3DXMatrixLookAtLH(&m_ViewMatrix, (D3DXVECTOR3*)&position, (D3DXVECTOR3*)&m_Target, (D3DXVECTOR3*)&up);

	Renderer::SetViewMatrix(&m_ViewMatrix);

	//�v���W�F�N�V�����}�g���b�N�X�ݒ�
	D3DXMATRIX projectionMatrix;
	D3DXMatrixPerspectiveFovLH(&projectionMatrix, 1.0f,
		(float)SCREEN_WIDTH / SCREEN_HEIGHT, 1.0f, 1000.0f);

	Renderer::SetProjectionMatrix(&projectionMatrix);

	//CAMERA camera;
	//D3DXVECTOR4 cpos = D3DXVECTOR4(m_Position.x, m_Position.y, m_Position.z, 1.0f);
	//camera.Position = cpos;
	//camera.FogParam.x = m_Param.x;//FogStart
	//camera.FogParam.y = m_Param.y;//FogEnd
	//camera.FogParam.z = m_Param.z;//FogHeight
	//camera.FogColor = D3DXCOLOR(m_FogColor.r, m_FogColor.g, m_FogColor.b, m_FogColor.a);
	//camera.GroundFogColor = D3DXCOLOR(m_GroundFogColor.r, m_GroundFogColor.g, m_GroundFogColor.b, m_GroundFogColor.a);
	//Renderer::SetCamera(camera);
}
#endif
