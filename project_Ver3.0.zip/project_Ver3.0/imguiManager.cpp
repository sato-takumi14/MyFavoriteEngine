#ifdef _DEBUG


#include  "main.h"
#include "renderer.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "input.h"
#include "imguiManager.h"
#include <thread>
#include <mutex>
#include <future>

char ImguiManager::m_Buffer[1024];
bool ImguiManager::m_IsDrawCamera = true;
void ImguiManager::Init()
{
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls
    io.DisplaySize.x = SCREEN_WIDTH;
    io.DisplaySize.y = SCREEN_HEIGHT;

    ImGui_ImplWin32_Init(GetWindow());
	ImGui_ImplDX11_Init(Renderer::GetDevice(), Renderer::GetDeviceContext());
}

void ImguiManager::Uninit()
{
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();

    ImGui::DestroyContext();
}

void ImguiManager::Begin()
{
    static Vector2 pos(0.0f, 0.0f);
    static float f;
    pos = Input::GetMousePos();
    RECT windowRect;
    GetClientRect(GetWindow(), &windowRect);
    int windowWidth = windowRect.right - windowRect.left;
    int windowHeight = windowRect.bottom - windowRect.top;

    static ImVec2 WindowSize(windowWidth * 0.5f, windowHeight * 0.5f);
    static ImVec2 windowPos((SCREEN_WIDTH- WindowSize.x) /2.0f,0);
    //ImGui::SetNextWindowPos(windowPos);
    //ImGui::SetNextWindowSize(WindowSize);
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    ImGui::SetNextWindowPos(windowPos);
    ImGui::Begin("game", 0, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_AlwaysAutoResize| ImGuiWindowFlags_MenuBar);
    if(ImGui::BeginMenuBar()) {
        static std::string str = "Game";
        const char* menuName = str.c_str();
        if (ImGui::BeginMenu(menuName)) {
            // "Open"���j���[�A�C�e��
            if (ImGui::MenuItem("Game", "Ctrl+O")) {
                // "Open"���I�����ꂽ���̏���
                str = "Game";
                m_IsDrawCamera = true;
            }
            // "Save"���j���[�A�C�e��
            if (ImGui::MenuItem("Secne", "Ctrl+S")) {
                // "Save"���I�����ꂽ���̏���
                str = "Secne";

                m_IsDrawCamera = false;
            }
            ImGui::EndMenu();
        }
        ImGui::EndMenuBar();
    }

    ImGui::Image(Renderer::GetTexture(1), WindowSize);
   // WindowSize = ImGui::GetWindowSize();
    ImGui::End();

    ImGui::Begin("debug", 0, ImGuiWindowFlags_NoScrollbar);
    if (m_IsDrawCamera)
    {
        ImGui::Text("true");
    }
    else
        ImGui::Text("false");

    //ImGui::Text("%f,%f", pos.x, pos.y);
    //ImGui::SliderFloat("float", &f, 0.0f, 1.0f);

    
}


void ImguiManager::End()
{
    ImGui::End();
    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

#endif // _DEBUG