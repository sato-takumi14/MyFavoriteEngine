#pragma once
enum MouseInput
{
	None,
	LButtonDown,
	MButtonDown,
	RButtonDown,
	LButtonUp,
	MButtonUp,
	RButtonUp,
};
#define MOUSE_TRIGGER_LEFT	  0x00000001
#define MOUSE_TRIGGER_RIGHT	  0x00000002
#define MOUSE_TRIGGER_CENTER  0x00000004
#define MOUSE_DOWN_LEFT		  0x00000010
#define MOUSE_DOWN_RIGHT	  0x00000020
#define MOUSE_DOWN_CENTER	  0x00000040
#define MOUSE_UP_LEFT		  0x00000010
#define MOUSE_UP_RIGHT		  0x00000020
#define MOUSE_UP_CENTER		  0x00000040



class Input
{
private:
	static BYTE m_OldKeyState[256];
	static BYTE m_KeyState[256];
	static POINT m_MousePos;
	static POINT m_Mousecenterpos;
	static MouseInput m_MouseInput;
	static MouseInput m_OldMouseInput;
	static BOOL m_Mosueflg;
	static BOOL m_MosueOldflg;

public:
	static void Init();
	static void Uninit();
	static void Update();

	static bool GetKeyPress(BYTE KeyCode);
	static bool GetKeyTrigger(BYTE KeyCode);
	static Vector2 GetMousePos();
	static bool GetMouseInput(BOOL inputDefine);//Input��Define������
};