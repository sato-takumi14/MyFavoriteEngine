#pragma once

class Manager
{
private:
public:
	static void Init();
	static void Uninit();
	static void Update();
	static void Draw();


};