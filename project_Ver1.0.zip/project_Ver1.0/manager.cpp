#include "main.h"
#include "manager.h"
#include "renderer.h"
#include "imguiManager.h"
#include "input.h"
#include "scene.h"
#include "post.h"

Scene* scene;
Post*  post;

void Manager::Init()
{
	Renderer::Init();
	ImguiManager::Init();
	Input::Init();
	scene = new Scene();
	scene->Init();

	post = new Post();
	post->Init();
}

void Manager::Uninit()
{
	scene->Uninit();
	delete scene;

	post->Uninit();
	delete post;

	Input::Uninit();
	ImguiManager::Uninit();
	Renderer::Uninit();
}

void Manager::Update()
{
	Input::Update();

	scene->Update();

	post->Update();
}

void Manager::Draw()
{
	Renderer::BeginPP();

	scene->Draw();

	Renderer::Begin();
	ImguiManager::Begin();

	post->Draw();

	ImguiManager::End();
	Renderer::End();
}
