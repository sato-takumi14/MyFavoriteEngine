#pragma once
#include "gameObject.h"

class AlphaBG : public GameObject
{
public:
	void Init()override;
	void FInit()override;
	void Uninit()override;
	void Update()override;
	void Draw()override;

	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "AlphaBG";
	}
};

