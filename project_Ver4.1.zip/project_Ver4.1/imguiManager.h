#pragma once
#include <unordered_map>
#include<string>

class  ImguiManager
{
private:
	static char m_Buffer[1024];
	static std::unordered_map < std::string , class Gui* > m_Guis;
	static Vector2 m_WindowSize;

	static void AddGui(Gui*);
	

public:
	static void Init();
	static void Uninit();
	static void Update();
	static void Begin();
	static void End();

	static Gui* GetGui(std::string name);
	static void SetWindowSize(Vector2 size);

};
