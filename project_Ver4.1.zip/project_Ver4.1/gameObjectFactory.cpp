#include "gameObjectFactory.h"

map<string, function<GameObject* ()>> GameObjectFactory::m_ClassNames;
