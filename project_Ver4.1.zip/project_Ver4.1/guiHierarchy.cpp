#include  "main.h"
#include "renderer.h"
#include "imgui_impl_dx11.h"
#include "imguiManager.h"
#include "guiHierarchy.h"
#include "guiInspector.h"
#include "gameObject.h"

void GuiHierarchy::Init()
{
}

void GuiHierarchy::Uninit()
{

}

void GuiHierarchy::Update()
{

}

void GuiHierarchy::Draw()
{
    ImGui::Begin("Hierarchy",0 );


    // ���[�g�I�u�W�F�N�g��\��
    for (auto obj:*m_GameObjects)
    {
        if (ImGui::Selectable(obj->GetName().c_str()))
        {
            dynamic_cast<GuiInspector*>(ImguiManager::GetGui(GuiInspector().GetName()))->SetGameObject(obj);
        }

    }
    

	ImGui::End();
}
