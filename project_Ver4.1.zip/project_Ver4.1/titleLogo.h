#pragma once
#include "gameObject.h"

class TitleLogo :public GameObject
{
private:
	class Sprite* m_sprite{};
public:
	void Init();
	void Uninit();
	void Update();
	void Draw();
	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "TitleLogo";
	}
};