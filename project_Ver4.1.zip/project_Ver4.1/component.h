#pragma once
#include  <fstream>
#include <string>



class Component
{
protected:
public:
	virtual void Init(){}
	virtual void FInit(){}
	virtual void Uninit(){}
	virtual void Update(){}
	virtual void Draw(){}

	virtual void Serialize(std::ofstream& file) const = 0;
	void SerializClassName(std::ofstream& file)
	{
		size_t size = GetMyClassName().size();
		file.write(reinterpret_cast<const char*>(&size), sizeof(size_t));
		file.write(GetMyClassName().data(), sizeof(size));
	}
	virtual void Deserialize(std::ifstream& file) = 0;
	virtual const std::string GetMyClassName()  = 0;
};

