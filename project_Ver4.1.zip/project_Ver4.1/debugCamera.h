#pragma once
#ifdef _DEBUG

class DebugCamera
{
private:
	static class Transform* m_Transform;
	static Vector3	    m_Target;
	static D3DXMATRIX m_ViewMatrix;
	static Vector2 m_LeftClickMousePos;
	static Vector3 m_LeftClickCameraRot;
	static Vector2 m_RightClickMousePos;
	static Vector3 m_RightClickCameraPos;
	static bool	   m_IsMouseUp;
	static bool m_IsFocusWindow;
public:
	static void Init();
	static void Update();
	static void Draw();
	static void SetFocusWindow() { m_IsFocusWindow = true; }
};
#endif // _DEBUG