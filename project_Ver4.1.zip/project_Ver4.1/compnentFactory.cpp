#include "main.h"
#include "renderer.h"
#include "component.h"
#include "compnentFactory.h"
#include "transform.h"
#include "boxCollider.h"
#include "circleCollider.h"
#include "collider.h"
#include "collision.h"
#include "material.h"
#include "plane.h"
#include "sprite.h"
#include "spriteAnimation.h"

std::map<std::string, std::function<Component* ()>> CompnentFactory::m_ClassNames;

CompnentFactory::CompnentFactory()
{
    {
        m_ClassNames["Component"] = []() {return nullptr; };
        m_ClassNames["Transform"] = []() {return new Transform(); };
        m_ClassNames["BoxCollider"] = []() {return new BoxCollider(); };
        m_ClassNames["CircleCollider"] = []() {return new CircleCollider(); };
        m_ClassNames["Collider"] = []() {return new Collider(); };
        m_ClassNames["Material"] = []() {return new Material(); };
        m_ClassNames["Plane"] = []() {return new Plane(); };
        m_ClassNames["Sprite"] = []() {return new Sprite(); };
        m_ClassNames["SpriteAnimation"] = []() {return new SpriteAnimation(); };

    }
}
