#pragma once
#include"gameObject.h"
#include"alphaBG.h"
#include"camera.h"
#include"enemy.h"
#include"fade.h"
#include"field.h"
#include"fieldNM.h"
#include"fogField.h"
#include"player.h"
#include"polygon2D.h"
#include"resultLogo.h"
#include"skyDome.h"
#include"titleLogo.h"
#include <map>
#include <string>
#include <functional>

using namespace std;
class GameObjectFactory
{
private:
	static map<string, function<GameObject* ()>> m_ClassNames;
public:
	GameObjectFactory()
	{
		m_ClassNames["AlphaBG"] = []() {return new AlphaBG; };
		m_ClassNames["Camera"] = []() {return new Camera; };
		m_ClassNames["Enemy"] = []() {return new Enemy; };
		m_ClassNames["Fade"] = []() {return new Fade; };
		m_ClassNames["Field"] = []() {return new Field; };
		m_ClassNames["FieldNM"] = []() {return new FieldNM; };
		m_ClassNames["FogField"] = []() {return new FogField; };
		m_ClassNames["Player"] = []() {return new Player; };
		m_ClassNames["Polygon2D"] = []() {return new Polygon2D; };
		m_ClassNames["ResultLogo"] = []() {return new ResultLogo; };
		m_ClassNames["SkyDome"] = []() {return new SkyDome; };
		m_ClassNames["TitleLogo"] = []() {return new TitleLogo; };
	}

	static GameObject* CreateInstance(string className)
	{
		auto it = m_ClassNames.find(className);
		if (it != m_ClassNames.end()) {
			return (it->second)();
		}
		else {
			// �G���[�n���h�����O: �o�^����Ă��Ȃ��N���X���̏ꍇ��nullptr��Ԃ�
			return nullptr;
		}
	}
};

