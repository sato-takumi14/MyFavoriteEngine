#pragma once
#include "GUI.h"
#include <string>


class GuiDrawGame:public Gui
{
private:
	bool m_IsDrawCamera;
	bool m_IsPlay;
	bool m_IsStop;
public:
	void Init()override;
	void Uninit()override;
	void Update()override;
	void Draw()override;
	bool GetDrawCamera() { return m_IsDrawCamera; }
	bool GetPlayPush() { return m_IsPlay; }
	bool GetStopPush() { return m_IsStop; }
	std::string GetName()override { return "Game"; }
};