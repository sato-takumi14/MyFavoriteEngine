#include "main.h"
#include "renderer.h"
#include "alphaBG.h"
#include "sprite.h"
#include "material.h"

void AlphaBG::Init()
{
	GameObject::Init();
	AddComponent<Material>()->Init("shader\\alphaBGVS.cso",
		"shader\\alphaBGPS.cso");
   AddComponent<Sprite>()->Init(0.0f, 0.0f, SCREEN_WIDTH, SCREEN_HEIGHT);
}

void AlphaBG::FInit()
{
	GameObject::FInit();
	GetComponent<Material>()->Init("shader\\alphaBGVS.cso",
		"shader\\alphaBGPS.cso");
	GetComponent<Sprite>()->Init(0.0f, 0.0f, SCREEN_WIDTH, SCREEN_HEIGHT);
}

void AlphaBG::Uninit()
{
	GameObject::Uninit();
}

void AlphaBG::Update()
{
	GameObject::Update();
}

void AlphaBG::Draw()
{
	//�}�g���b�N�X�ݒ�
	Renderer::SetWorldViewProjection2D();

	ID3D11ShaderResourceView* bgTexture = Renderer::GetTexture(1);
	Renderer::GetDeviceContext()->PSSetShaderResources(0, 1, &bgTexture);

	ID3D11ShaderResourceView* gameTexture = Renderer::GetTexture(2);
	Renderer::GetDeviceContext()->PSSetShaderResources(1, 1, &gameTexture);

	GameObject::Draw();
}

void AlphaBG::AddSerialize(ofstream& file) const
{

}

void AlphaBG::AddDeserialize(ifstream& file)
{

}
