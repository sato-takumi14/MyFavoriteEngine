#include  "main.h"
#include "renderer.h"
#include "imgui_impl_dx11.h"
#include "guiDrawGame.h"
#include "debugCamera.h"
void GuiDrawGame::Init()
{
    m_IsDrawCamera = true;
    m_IsPlay = false;
    m_IsStop = false;
}

void GuiDrawGame::Uninit()
{
}

void GuiDrawGame::Update()
{
    m_IsPlay = false;
    m_IsStop = false;
}

void GuiDrawGame::Draw()
{
    //RECT windowRect;
    //GetClientRect(GetWindow(), &windowRect);
    //float windowWidth = static_cast<float>(windowRect.right - windowRect.left);
    //float windowHeight = static_cast<float>(windowRect.bottom - windowRect.top);
    // 
    // �E�B���h�E�̕\���̈���擾
    ImGuiViewport* viewport = ImGui::GetMainViewport();
    ImVec2 viewportPos = viewport->Pos;
    ImVec2 viewportSize = viewport->Size;
    int windowWidth = static_cast<int>(viewportSize.x);
    int windowHeight = static_cast<int>(viewportSize.y);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = static_cast<float>(windowWidth);
    io.DisplaySize.y = static_cast<float>(windowHeight);

    ImVec2 WindowSize(windowWidth * 0.5f, windowHeight * 0.5f);
    ImVec2 windowPos((windowWidth / 2.0f) - (windowWidth / 4.0f), 0);
    ImGui::SetNextWindowPos(windowPos);
    ImGui::Begin("game", 0, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_MenuBar| ImGuiWindowFlags_NoResize| ImGuiWindowFlags_AlwaysAutoResize);
    if (ImGui::BeginMenuBar()) {
        static std::string str = "Game";
        const char* menuName = str.c_str();
        if(ImGui::BeginMenu(menuName))
        {
            // "Open"���j���[�A�C�e��
            if (ImGui::MenuItem("Game", "Ctrl+O")) {
                // "Open"���I�����ꂽ���̏���
                str = "Game";
                m_IsDrawCamera = true;
            }
            // "Save"���j���[�A�C�e��
            if (ImGui::MenuItem("Secne", "Ctrl+S")) {
                // "Save"���I�����ꂽ���̏���
                str = "Secne";

                m_IsDrawCamera = false;
            }
            ImGui::EndMenu();
        }

        if (ImGui::MenuItem("play"))
        {
            m_IsPlay = true;
        }

        if (ImGui::MenuItem("stop"))
        {
            m_IsStop = true;
        }

        ImGui::EndMenuBar();
    }
    bool isChildWindowFocused = ImGui::IsWindowFocused(ImGuiFocusedFlags_ChildWindows);
    bool isMouseHoveringChildWindow = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows);

    if (isChildWindowFocused && isMouseHoveringChildWindow)
    {
        DebugCamera::SetFocusWindow();
    }
    ImGui::Image(Renderer::GetTexture(Renderer::GetNumRenderTexture() - 1), WindowSize);
    // WindowSize = ImGui::GetWindowSize();
    ImGui::End();
}


