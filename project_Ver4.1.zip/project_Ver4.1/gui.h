#pragma once
#include <string>

class Gui
{
protected:
public:
	virtual void Init() {}
	virtual void Uninit() {}
	virtual void Update() {}
	virtual void Draw() = 0;
	virtual std::string GetName() = 0;
};