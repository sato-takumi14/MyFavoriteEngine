#pragma once
#include "gameObjectFactory.h"
#include "gameObject.h"
#include "renderer.h"
#include <list>
#include <typeinfo>
#include <vector>
#include <map>
#include <string>
#include <fstream>

#include "debugCamera.h"
#include "imguiManager.h"
#include "GuiDrawGame.h"
#include"textureManager.h"
#include "modelManager.h"
#include "post.h"
using namespace std;

class Scene
{
protected:
	list<GameObject*> m_GameObjects;
	map<string, int> m_DrawOder;//string::���C���[�̖��O ,int::�`�揇��
	int m_LayerNum = 0;//���݂̃��C���[��
	Post m_Post{};
	bool IsFile = false;

public:

	void SetLayer(string name) 
	{
		m_DrawOder[name] = m_LayerNum++;
	}
	void SetLayer(string name,int num) 
	{
		if (num == m_LayerNum)
		{
			m_DrawOder[name] = m_LayerNum++;
		}
		else if (num < m_LayerNum)
		{
			for (int i = m_LayerNum - 1; i > num; i--)
			{
				string key;
				for (const auto& pair : m_DrawOder) {
					if (pair.second == i) {
						key = pair.first;
						break; // ���������烋�[�v�𔲂���
					}
				}
				m_DrawOder[key] = i + 1;
			}
			m_LayerNum++;
			m_DrawOder[name] = num;
		}
		else
		{
			assert("�v�f���͂���Ȃɂ���܂���");
		}
	}

	virtual void Init()
	{
		SetLayer("None");

		//�����_�����O�e�N�X�`����������邩���߂�
		for (int i = 0; i < 4; i++)
		{
			Renderer::CreateTexture(i);
		}

		for (GameObject* gameObject : m_GameObjects)
		{
			gameObject->FInit();
		}
#ifndef _DEBUG
		m_Post.Init();
#endif // !_DEBUG

	}

	virtual void Uninit()
	{
		for (GameObject* gameObject:m_GameObjects)
		{
			gameObject->Uninit();
			delete gameObject;
		}
#ifndef _DEBUG
		m_Post.Uninit();
#endif // !_DEBUG

		m_GameObjects.clear();
		TextureManager::Uninit();
		ModelManager::Uninit();
	}

	virtual void Update()
	{
		for (GameObject* gameObject : m_GameObjects)
		{
			gameObject->Update();
		}
		m_GameObjects.remove_if([](GameObject* object) {return object->Destroy(); });
#ifndef _DEBUG
		m_Post.Update();
#endif // !_DEBUG
	}

	virtual void Draw()
	{
#ifdef _DEBUG
#endif // _DEBUG
		for (int j = 0; j < Renderer::GetNumRenderTexture(); j++)
		{
			Renderer::Begin(j);
			for (GameObject* gameObject : m_GameObjects)
			{
				if (gameObject->GetRTextureId(j) == j)
				{
					for (int i = 0; i < m_LayerNum; i++)
					{

						if (m_DrawOder["fade"] == gameObject->GetLayerNum())
						{
							Renderer::BeginPP();
#ifndef _DEBUG
							m_Post.Draw();
							gameObject->Draw();
#endif // !_DEBUG
						}
#ifdef _DEBUG
						else if (m_DrawOder["camera"] == gameObject->GetLayerNum())
						{
							if (dynamic_cast<GuiDrawGame*>(ImguiManager::GetGui(GuiDrawGame().GetName()))->GetDrawCamera())
							{
								gameObject->Draw();
							}
							else
							{
								DebugCamera::Draw();

							}
						}
#endif // _DEBUG
						else if (i == gameObject->GetLayerNum())
							gameObject->Draw();
					}
				}
			}
		}
		//Layer::Draw();

	}

	template<typename T>
	T* AddGameObject(string name = "None", int id = Renderer::GetNumRenderTexture() - 2)
	{
		GameObject* gameObject = new T;
		m_GameObjects.push_back(gameObject);
		gameObject->Init();

		gameObject->SetLayerNum(m_DrawOder[name]);
		gameObject->SetRTextureId(id);

		return dynamic_cast<T*>(gameObject);
	}

	template<typename T>
	T* AddGameObjectRT(string name = "None", vector<int> id = nullptr)
	{
		GameObject* gameObject = new T;
		m_GameObjects.push_back(gameObject);
		gameObject->Init();

		gameObject->SetLayerNum(m_DrawOder[name]);
		gameObject->SetRTextureId(id);

		return dynamic_cast<T*>(gameObject);
	}

	template<typename T>
	vector<T*>GetGameObjects()
	{
		vector<T*>objects;
		for (GameObject* object : m_GameObjects)
		{
			if (typeid(*object) == typeid(T))
			{
				objects.push_back((T*)object);
			}
		}
		return objects;
	}

	list<GameObject*>* GetGameObjectsList() { return &m_GameObjects; }

	// �V���A���C�Y�i�o�C�i���t�@�C���ɏ������ށj�֐�
	void Serialize(ofstream& file) const {
		
		{//m_DrawOder
			size_t size = m_DrawOder.size();
			file.write(reinterpret_cast<const char*>(& size), sizeof(size_t));//m_DrawOder�̐��̏�������

			for (auto &layer : m_DrawOder)
			{
				size_t size = layer.first.size();
				file.write(reinterpret_cast<const char*>(&size), sizeof(size_t));//���C���[���̕����̒���
				file.write(layer.first.data(), size);//���C���[��
				file.write(reinterpret_cast<const char*>(&layer.second), sizeof(int));//���C���[����
			}
		}
		{
			size_t numGameObjects = m_GameObjects.size();
			file.write(reinterpret_cast<const char*>(&numGameObjects), sizeof(size_t));//GameObject�̐��̏�������
			for (const auto& gameObjectPtr : m_GameObjects) {
				size_t size = gameObjectPtr->GetMyClassName().size();
				file.write(reinterpret_cast<const char*>(&size), sizeof(size_t));//�^���̑傫��
				file.write(gameObjectPtr->GetMyClassName().data(), size);//�^��
				gameObjectPtr->Serialize(file);
			}
		}
	}

	// �f�V���A���C�Y�i�o�C�i���t�@�C������ǂݍ��ށj�֐�
	void Deserialize(ifstream& file) {

		{//m_DrawOder
			size_t size = 0;
			file.read(reinterpret_cast<char*>(& size), sizeof(size_t));
			m_DrawOder.clear();
			for (size_t i = 0; i < size; i++)
			{
				size_t sizeStoring = 0;
				file.read(reinterpret_cast<char*>(&sizeStoring), sizeof(size_t));
				string name;
				name.resize(sizeStoring);
				file.read(&name[0], sizeStoring);
				int value = 0;
				file.read(reinterpret_cast<char*>(&value), sizeof(int));

				m_DrawOder[name] = value;
			}
			m_LayerNum = static_cast<int>(size);
		}

		{//m_GameObjects
			size_t numGameObjects = 0;
			file.read(reinterpret_cast<char*>(&numGameObjects), sizeof(size_t));
			m_GameObjects.clear();
			for (size_t i = 0; i < numGameObjects; ++i) {
				size_t size = 0;
				file.read(reinterpret_cast<char*>(&size), sizeof(size_t));
				string className;
				className.resize(size);
				file.read(&className[0], size);
				GameObject* gameObjectPtr = GameObjectFactory().CreateInstance(className);
				gameObjectPtr->Deserialize(file);
				m_GameObjects.push_back(gameObjectPtr);
			}
		}
		IsFile = true;
	}

	bool GetIsFile() { return IsFile; }
};