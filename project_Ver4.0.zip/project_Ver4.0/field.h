#pragma once
#include"gameObject.h"

class Field :public GameObject
{
private:

public:
	void Init();
	void FInit()override;
	void Uninit();
	void Update();
	void Draw();
	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "Field";
	}
};

