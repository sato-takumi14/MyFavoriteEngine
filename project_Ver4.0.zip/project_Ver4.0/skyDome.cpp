#include "main.h"
#include "manager.h"
#include "renderer.h"
#include "scene.h"
#include "skyDome.h"
#include "camera.h"
#include "modelManager.h"
#include "material.h"


void SkyDome::Init()
{
	
	m_Index = ModelManager::Load((char*)"asset\\model\\sky.obj");
	GameObject::Init();

	m_Transform->SetWorldPosition(Vector3(0.0f, -40.0f, 0.0f));
	m_Transform->SetWorldRotation(Vector3(D3DX_PI / 4, 0.0f, 0.0f));
	m_Transform->SetWorldScale(Vector3(100.0f, 100.0f, 100.0f));

	AddComponent<Material>()->Init("shader\\unlitTextureVS.cso", "shader\\unlitTexturePS.cso");
}

void SkyDome::FInit()
{
	m_Index = ModelManager::Load((char*)"asset\\model\\sky.obj");
	GameObject::FInit();
	GetComponent<Material>()->Init("shader\\unlitTextureVS.cso", "shader\\unlitTexturePS.cso");
}

void SkyDome::Uninit()
{
	GameObject::Uninit();
}
void SkyDome::Update()
{
	GameObject::Update();

	/*Scene* scene = Manager::GetScene();
	Camera* camera = scene->GetGameObject<Camera>();

	m_Position = camera->GetPosition() + -GetUp() * 10.0f;

	m_Rotation.y += 0.0001f;*/
}

void SkyDome::Draw()
{
	//�}�g���b�N�X�ݒ�
	Vector3 posVec = m_Transform->GetWorldPosition();
	Vector3 rotVec = m_Transform->GetWorldRotation();
	Vector3 sclVec = m_Transform->GetWorldScale();

	D3DXMATRIX world, scale, rot, trans;
	D3DXMatrixScaling(&scale, sclVec.x, sclVec.y, sclVec.z);
	D3DXMatrixRotationYawPitchRoll(&rot, rotVec.y, rotVec.x, rotVec.z);
	D3DXMatrixTranslation(&trans, posVec.x, posVec.y, posVec.z);
	world = scale * rot * trans;

	Renderer::SetWorldMatrix(&world);

	GameObject::Draw();
	ModelManager::GetModel(m_Index)->Draw();
}

void SkyDome::AddSerialize(ofstream& file) const
{
}

void SkyDome::AddDeserialize(ifstream& file)
{
}
