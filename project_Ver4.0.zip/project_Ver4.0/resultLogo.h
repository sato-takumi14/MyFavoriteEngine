#pragma once
#include "gameObject.h"

class ResultLogo :public GameObject
{
public:
	void Init();
	void Uninit();
	void Update();
	void Draw();
	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "ResultLogo";
	}
};