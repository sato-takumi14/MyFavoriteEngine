#include "main.h"
#include "manager.h"
#include "renderer.h"
#include "imguiManager.h"
#include "guiHierarchy.h"
#include "GuiDrawGame.h"
#include "guiInspector.h"
#include "debugCamera.h"

#include "scene.h"
#include "binaryfileManager.h"
#include "input.h"
#include "post.h"
#include "title.h"
#include "game.h"
#include "load.h"

Scene* Manager::m_Scene{};//�ÓI�����o�ϐ��͍Đ錾���K�v
Scene* Manager::m_NextScene{};
Scene* Manager::m_NextSceneLoad{};

#ifdef _DEBUG
bool Manager::m_IsPlayGame = false;
#endif // _DEBUG
//ImGuiManager�̓f�o�b�O��p
void Manager::Init()
{
	Renderer::Init();
#ifdef _DEBUG
	ImguiManager::Init();
	DebugCamera::Init();

#endif // DEBUG
	Input::Init();

	//SetScene<Game>();
	m_NextScene = BinaryFileManager::LoadFromFile("asset/binaryfile/scene.bin");
}

void Manager::Uninit()
{
	m_Scene->Uninit();
	delete m_Scene;


	Input::Uninit();
#ifdef _DEBUG
	ImguiManager::Uninit();
#endif // _DEBUG
	Renderer::Uninit();
}

void Manager::Update()
{
	Input::Update();


	if (m_NextScene)
	{
		if (m_Scene)
		{
			m_Scene->Uninit();
			delete m_Scene;
		}

		m_Scene = m_NextScene;
		m_Scene->Init();
#ifdef _DEBUG
		dynamic_cast<GuiHierarchy*>(ImguiManager::GetGui(GuiHierarchy().GetName()))->SetGameObjectList(m_Scene->GetGameObjectsList());
#endif
		m_NextScene = nullptr;
	}

	if (m_NextSceneLoad)
	{
		if (m_Scene)
		{
			m_Scene->Uninit();
			delete m_Scene;
		}

		
		m_Scene = m_NextSceneLoad;
		

		m_NextSceneLoad = nullptr;
	}

#ifndef _DEBUG
	m_Scene->Update();
#else
	if (dynamic_cast<GuiDrawGame*>(ImguiManager::GetGui(GuiDrawGame().GetName()))->GetPlayPush() && !m_IsPlayGame)
	{
		m_IsPlayGame = true;
	}
	if (dynamic_cast<GuiDrawGame*>(ImguiManager::GetGui(GuiDrawGame().GetName()))->GetStopPush() && m_IsPlayGame)
	{
		m_IsPlayGame = false;
		m_Scene->Uninit();
		if(m_Scene->GetIsFile())
		m_Scene = BinaryFileManager::LoadFromFile("asset/binaryfile/scene.bin");
		m_Scene->Init();
		dynamic_cast<GuiHierarchy*>(ImguiManager::GetGui(GuiHierarchy().GetName()))->SetGameObjectList(m_Scene->GetGameObjectsList());
		dynamic_cast<GuiInspector*>(ImguiManager::GetGui(GuiInspector().GetName()))->SetGameObject(nullptr);

	}
	if (m_IsPlayGame)
	{
		m_Scene->Update();

	}


	ImguiManager::Update();
	if(!dynamic_cast<GuiDrawGame*>(ImguiManager::GetGui(GuiDrawGame().GetName()))->GetDrawCamera())
	DebugCamera::Update();


	//�t�@�C���ɕۑ�
	if (Input::GetKeyTrigger(VK_CONTROL))
	{
		BinaryFileManager::SaveToFile(*m_Scene, "asset/binaryfile/scene.bin");
	}

#endif // _DEBUG

}

void Manager::Draw()
{
#ifdef _DEBUG
	ImguiManager::Begin();
#endif // _DEBUG
    m_Scene->Draw();

#ifdef _DEBUG
	ImguiManager::End();
#endif // _DEBUG
	Renderer::End();

}

void Manager::SetSceneLoad(Scene* next_scene)
{
	m_NextScene = new Load(next_scene);
}