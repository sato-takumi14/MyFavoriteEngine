#pragma once
#include "gameObject.h"

class Player :public GameObject
{
private:
	int m_Index = -1;

	ID3D11ShaderResourceView* m_TextureNormalMap = NULL;
public:
	void Init()override;
	void FInit()override;
	void Uninit()override;
	void Update()override;
	void Draw()override;
	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "Player";
	}
};