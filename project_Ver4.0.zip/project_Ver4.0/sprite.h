#pragma once
#include "component.h"

class Sprite:public Component
{
private:
	ID3D11Buffer* m_VertexBuffer{};
	int m_Index = -1;//�e�N�X�`���ԍ�
	bool m_NonTexture = false;//�e�N�X�`���̗L��

public:
	void Init(float x, float y, float width, float height);
	void Init(float x, float y, float width, float height, const  char* file);
	void Uninit()override;
	void Update()override;
	void Draw()override;

	void Serialize(std::ofstream& file) const override;
	void Deserialize(std::ifstream& file) override;
	const std::string GetMyClassName() override
	{
		return "Sprite";
	}
};