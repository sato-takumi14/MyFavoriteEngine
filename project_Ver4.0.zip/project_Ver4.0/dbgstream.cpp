// -*- mode: c++ -*-

#include "dbgstream.h"

debug_stream cdbg;
