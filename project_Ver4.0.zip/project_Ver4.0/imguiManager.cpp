
//system�ǉ�
#include  "main.h"
#include "renderer.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "imguiManager.h"


//gui�N���X�ǉ�
#include "gui.h"

#include "GuiHierarchy.h"
#include "GuiDrawGame.h"
#include "guiInspector.h"


//C++�W�����C�u�����ǉ�
#include <thread>
#include <mutex>
#include <future>

char ImguiManager::m_Buffer[1024];
std::unordered_map < std::string, class Gui* > ImguiManager::m_Guis;
Vector2 ImguiManager::m_WindowSize{};


//gui�ǉ��֐�
void ImguiManager::AddGui(Gui* gui)
{
    m_Guis[gui->GetName()] = gui;
    m_Guis[gui->GetName()]->Init();
}

void ImguiManager::Init()
{
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls
    io.DisplaySize.x = SCREEN_WIDTH;
    io.DisplaySize.y = SCREEN_HEIGHT;

    ImGui_ImplWin32_Init(GetWindow());
	ImGui_ImplDX11_Init(Renderer::GetDevice(), Renderer::GetDeviceContext());


    AddGui(new GuiDrawGame);
    AddGui(new GuiHierarchy);
    AddGui(new GuiInspector);


}

void ImguiManager::Uninit()
{
    for (auto gui:m_Guis)
    {
        gui.second->Uninit();
        delete gui.second;
    }
    m_Guis.clear();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();

    ImGui::DestroyContext();
}

void ImguiManager::Update()
{

    for (auto gui : m_Guis)
    {
        gui.second->Update();
    }
}

void ImguiManager::Begin()
{
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    

    for (auto gui : m_Guis)
    {
        gui.second->Draw();
    }

    ImGui::Begin("debug", 0, ImGuiWindowFlags_NoScrollbar);
}


void ImguiManager::End()
{
    ImGui::End();
    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

Gui* ImguiManager::GetGui(std::string name)
{
    return m_Guis[name];
}

void ImguiManager::SetWindowSize(Vector2 size)
{
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    io.DisplaySize.x = size.x;
    io.DisplaySize.y = size.y;
}



// ImGui�E�B���h�E��Ƀ}�E�X�����邩�ǂ����𔻒肵�A�E�B���h�E����Ԃ��֐�

