#pragma once
#include "gui.h"
#include <list>
class GuiHierarchy :public Gui
{
private:
	std::list<class GameObject*>* m_GameObjects;
public:
	void Init()override;
	void Uninit()override;
	void Update()override;
	void Draw()override;
	std::string GetName()override { return "Hierarchy"; }
	void SetGameObjectList(std::list<class GameObject*>* gameObjecs) {
		m_GameObjects = gameObjecs;
	}
};
