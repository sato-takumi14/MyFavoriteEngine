#pragma once
#include "gameObject.h"

class Camera:public GameObject
{
private:

	Vector3	    m_Target;
	D3DXVECTOR4 m_Param;
	D3DXCOLOR   m_FogColor;
	D3DXCOLOR   m_GroundFogColor;
	D3DXMATRIX m_ViewMatrix{};

public:
	void Init();
	void FInit()override;

	void Update();
	void Draw();
	void AddSerialize(ofstream& file)const override;
	void AddDeserialize(ifstream& file) override;
	const string GetMyClassName()override
	{
		return "Camera";
	}
};
