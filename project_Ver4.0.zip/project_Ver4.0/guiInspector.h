#pragma once
#include "gui.h"
class GameObject;
class GuiInspector :public Gui
{
private:
	GameObject* m_GameObject;
public:
	void Init()override;
	void Uninit()override;
	void Update()override;
	void Draw()override;

	std::string GetName()override { return "Inspector"; }
	void SetGameObject(GameObject* gameObject) 
	{ 
		m_GameObject = gameObject; 
	}

private:
	void DrawTransform();

};
